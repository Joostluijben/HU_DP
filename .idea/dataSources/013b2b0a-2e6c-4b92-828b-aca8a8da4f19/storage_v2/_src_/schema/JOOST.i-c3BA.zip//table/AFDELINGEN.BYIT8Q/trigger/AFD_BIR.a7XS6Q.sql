create trigger AFD_BIR
  before insert
  on AFDELINGEN
  for each row
  BEGIN
    SELECT afd_nr_seq.NEXTVAL
    INTO
    :new.anr
    FROM
    dual;
END;
/

